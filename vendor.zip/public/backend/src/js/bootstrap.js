// Load plugins
import cash from 'cash-dom'
import helper from './helper'

// Set plugins globally
window.cash = cash
window.helper = helper