 <div class="container">
  <div class="section">
        <div class="container">
          <div class="row align-items-center col-spacing-50">
            <div class="col-12">
              {!! clean($textarea) !!}
            </div>
          </div><!-- end row -->
        </div><!-- end container -->
      </div>
   </div>