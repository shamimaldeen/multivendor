
	    <!-- Section About Us -->
	    <section id="about" class="container section">
	        <div class="row">
		        <div class="col-12 col-lg-5">
			        <span class="title title--overhead js-lines">{{ __('Our story') }}</span>
			        <h1 class="title title--h1 js-lines">{{ $title }}</h1>
			    </div>
				<div class="col-12 col-lg-6 offset-lg-1 offset-top">
				    <p class="paragraph js-scroll-show">{{ $description }}</p>
				</div>
		    </div>
		</section>