
      <div class="col-lg-10 mx-auto text-center mt-7">
        <h2>{{ $title }}</h2>
      </div>