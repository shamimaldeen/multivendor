(function ($) {
  "use strict";
  
})(jQuery);