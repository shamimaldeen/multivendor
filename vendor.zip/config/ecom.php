<?php 
 return [
  'jeff' => 'env(\'APP_URL\', \'http://localhost\')',
  'url' => 'me',
];