<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Track extends Model
{
    protected $table = 'track';
    public $timestamps = false;
}
