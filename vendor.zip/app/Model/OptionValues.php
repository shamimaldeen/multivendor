<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OptionValues extends Model
{
    protected $table = 'option_values';
}
