<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Pages_Category extends Model
{
    protected $table = 'pages_categories';
}
