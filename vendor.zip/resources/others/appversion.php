<?php
return [
    '2.0.6' => [
        'current'  => true
    ],
];
