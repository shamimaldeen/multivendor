<?php

return [
  "paypal" => [
    "name"     => "PayPal",
    "banner"   => "paypal.png"
  ],
  "bank" => [
    "name"     => "Bank",
    "banner"   => "banktransfer.png"
  ],
  "cash" => [
    "name"     => "Cash Payment",
    "banner"   => "cashpayment.png"
  ]
];
