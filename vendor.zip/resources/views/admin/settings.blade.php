@extends('admin.layouts.app')

@section('title', __('Settings'))
@section('content')
<div class="nk-block-head mb-4">
    <div class="nk-block-between-md g-4">
        <div class="nk-block-head-content">
            <h2 class="nk-block-title fw-normal">{{ __('Settings') }}</h2>
        </div>
    </div>
</div>
<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#home"><em class="icon ni ni-home"></em> <span>{{ __('Home') }}</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#user"><em class="icon ni ni-account-setting-alt"></em> <span>{{ __('User') }}</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#ads"><em class="icon ni ni-money"></em> <span>{{ __('Ads') }}</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#social"><em class="icon ni ni-viber"></em> <span>{{ __('Social') }}</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#custom-js-css"><em class="icon ni ni-js"></em> <span>{{ __('Custom head code') }}</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#emailsnotify"><em class="icon ni ni-bell"></em> <span>{{ __('Email') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#captcha"><em class="icon ni ni-policy"></em> <span>{{ __('Captcha') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#file-system"><em class="icon ni ni-aws"></em> <span>{{ __('File System') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#social_logins"><em class="icon ni ni-google"></em> <span>{{ __('Social logins') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#payment"><em class="icon ni ni-wallet"></em> <span>{{ __('Payment') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#business"><em class="icon ni ni-briefcase"></em> <span>{{ __('Business') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#site"><em class="icon ni ni-layout2"></em> <span>{{ __('Site') }}</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#smtp"><em class="icon ni ni-emails"></em> <span>{{ __('SMTP') }}</span></a>
    </li>
</ul>
<form action="{{ route('post.settings') }}" method="post" enctype="multipart/form-data">
	@csrf
	<div class="tab-content settings-card">
        <div class="tab-pane" id="file-system">
          <div class="form-group mt-5 col-md-6">
             <label class="form-label"><span>{{ __('File systen') }}</span></label>
             <div class="form-control-wrap">
                <select class="form-select" data-search="off" data-ui="lg" name="file_system">
                   <option value="public" {{ (env('FILESYSTEM') == 'public') ? 'selected' : '' }}> {{ __('Local server') }} </option>
                   <option value="s3" {{ (env('FILESYSTEM') == 's3') ? 'selected' : '' }}> {{ __('Amazone S3') }} </option>
               </select>
             </div>
          </div>
         <div class="data-head mt-5 mb-2">
            <h6 class="overline-title">{{ __('Amazone s3 configuration') }}</h6>
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group mt-4">
                  <label class="form-label">{{ __('AWS ACCESS KEY ID') }}</label>
                  <input type="text" name="aws_access_key_id" class="form-control form-control-lg" value="{{env('AWS_ACCESS_KEY_ID')}}">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mt-4">
                  <label class="form-label">{{ __('AWS SECRET ACCESS KEY') }}</label>
                  <input type="text" name="aws_secret_access_key" class="form-control form-control-lg" value="{{env('AWS_SECRET_ACCESS_KEY')}}">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mt-4">
                  <label class="form-label">{{ __('AWS DEFAULT REGION') }}</label>
                  <input type="text" name="aws_default_region" class="form-control form-control-lg" value="{{env('AWS_DEFAULT_REGION')}}" placeholder="eu-west-5">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group mt-4">
                  <label class="form-label">{{ __('AWS BUCKET') }}</label>
                  <input type="text" name="aws_bucket" class="form-control form-control-lg" value="{{env('AWS_BUCKET')}}">
              </div>
            </div>
          </div>



        </div>
        <div class="tab-pane" id="business">
          <h5>{{ __('Business Details') }}</h5>
          <p>{{ __('These details will be used when generating invoices for the user payments') }}</p>
          <div class="form-group mt-5">
             <label class="form-label"><span>{{ __('Invoicing System') }}</span></label>
             <div class="form-control-wrap">
                <select class="form-select" data-search="off" data-ui="lg" name="business_enabled">
                   <option value="1" {{ (settings('business.enabled') == 1) ? 'selected' : '' }}> {{ __('Yes') }} </option>
                   <option value="0" {{ (settings('business.enabled') == 0) ? 'selected' : '' }}> {{ __('No') }} </option>
               </select>
             </div>
          </div>
          <div class="row">
             <div class="col-6">
                 <div class="form-group">
                     <label class="form-label">{{ __('Name') }}</label>
                     <input type="text" name="business_name" class="form-control form-control-lg" value="{{settings('business.name')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Email') }}</label>
                     <input type="text" name="business_email" class="form-control form-control-lg" value="{{settings('business.email')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Phone') }}</label>
                     <input type="text" name="business_phone" class="form-control form-control-lg" value="{{settings('business.phone')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Tax Type') }}</label>
                     <input type="text" name="business_tax_type" class="form-control form-control-lg" value="{{settings('business.tax_type')}}" placeholder="ex: VAT">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Tax ID') }}</label>
                     <input type="text" name="business_tax_id" class="form-control form-control-lg" value="{{settings('business.tax_id')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Custom Field Key') }}</label>
                     <input type="text" name="business_custom_key_one" class="form-control form-control-lg" value="{{settings('business.custom_key_one')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Custom Field Key') }}</label>
                     <input type="text" name="business_custom_key_two" class="form-control form-control-lg" value="{{settings('business.custom_key_two')}}">
                 </div>
             </div>

             <div class="col-6">
                 <div class="form-group">
                     <label class="form-label">{{ __('Address') }}</label>
                     <input type="text" name="business_address" class="form-control form-control-lg" value="{{settings('business.address')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('City') }}</label>
                     <input type="text" name="business_city" class="form-control form-control-lg" value="{{settings('business.city')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('County') }}</label>
                     <input type="text" name="business_county" class="form-control form-control-lg" value="{{settings('business.county')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('ZIP') }}</label>
                     <input type="number" name="business_zip" class="form-control form-control-lg" value="{{settings('business.zip')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Country') }}</label>
                     <input type="text" name="business_country" class="form-control form-control-lg" value="{{settings('business.country')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Custom Field Value') }}</label>
                     <input type="text" name="business_custom_value_one" class="form-control form-control-lg" value="{{settings('business.custom_value_one')}}">
                 </div>

                 <div class="form-group">
                     <label class="form-label">{{ __('Custom Field Value') }}</label>
                     <input type="text" name="business_custom_value_two" class="form-control form-control-lg" value="{{settings('business.custom_value_two')}}">
                 </div>
             </div>
         </div>
        </div>
		    <div class="tab-pane active" id="home">
		    	<div class="row">
		    		<div class="col-md-6">
				    	<div class="form-group mt-5 mt-lg-2">
						    <label class="form-label"><em class="icon ni ni-italic"></em> <span>{{ __('Website title') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('Enter site name') }}" value="{{ env('APP_NAME') }}" name="title">
						    </div>
						 </div>
		    		</div>
            <div class="col-md-6">
              <div class="form-group mt-5 mt-lg-2">
                 <label class="form-label"><span> {{ __('Locale') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="on" data-ui="lg" name="locale">
                       @foreach ($alltransfiles as $value)
                          @php
                            $file = pathinfo($value);
                          @endphp
                          <option value="{{ strtolower($file['filename']) }}" {{config('app.locale') == strtolower($file['filename']) ? 'selected' : ''}}> {{ ucfirst($file['filename']) }} </option>
                       @endforeach
                   </select>
                 </div>
              </div>
            </div>
		    		<div class="col-md-6">
				    	<div class="form-group mt-4">
						    <label class="form-label"><em class="icon ni ni-mail"></em> <span>{{ __('Site Email') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="email" class="form-control form-control-lg" placeholder="{{ __('your email') }}" value="{{ settings('email') }}" name="email">
						    </div>
						</div>
		    		</div>
            <div class="col-md-6">
              <div class="form-group mt-5">
                <div class="custom-control custom-switch">
                  <input type="hidden" name="scheme" value="http">
                  <input type="checkbox" value="https" class="custom-control-input" id="scheme" name="scheme" {{ (env('APP_SCHEME') == 'https') ? "checked" : "" }}>
                  <label class="custom-control-label" for="scheme">{{ __('Force https scheme') }}</label>
               </div>
              </div>
            </div>
		    	</div>
		    	<div class="row">
		    		<div class="col-md-6">
              <div class="form-group mt-5">
                 <label class="form-label"><em class="icon ni ni-globe"></em> <span>{{ __('Timezone') }}</span></label>
                 <div class="form-control-wrap">
                    {!! $timezone !!}
                 </div>
              </div>
		    		</div>
		    		<div class="col-md-6">
                       <div class="form-group mt-5">
                          <label class="form-label"><em class="icon ni ni-map"></em> <span>{{ __('optional') }}</span> <small>{{ __('optional') }}</small></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('enter your location') }}" value="{{ settings('location') }}" name="location">
						    </div>
                       </div>
		    		</div>
		    		<div class="col-md-6">
                       <div class="form-group mt-5">
                          <label class="form-label"><em class="icon ni ni-home"></em> <span>{{ __('Custom index url') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="url" class="form-control form-control-lg" placeholder="{{ __('enter your location') }}" value="{{ settings('custom_home') }}" name="custom_home">
						    </div>
						    <p>{{ __('Set the full custom index url ( ex: https://google.com/ ) if you want to completely disable the default landing page of the product. Helpful when you want to have your own landing page. Leave empty to disable.') }}</p>
                       </div>
		    		</div>
		    		<div class="col-md-6">
                       <div class="form-group mt-5">
                          <label class="form-label"><em class="icon ni ni-notes-alt"></em> <span>{{ __('Terms url') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('enter your location') }}" value="{{ settings('terms') }}" name="terms">
						    </div>
                       </div>
		    		</div>
		    		<div class="col-md-6">
                       <div class="form-group mt-5">
                          <label class="form-label"><em class="icon ni ni-shield-star"></em> <span>{{ __('Privacy url') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('enter your location') }}" value="{{ settings('privacy') }}" name="privacy">
						    </div>
                       </div>
		    		</div>
		    	</div>
		    </div>
        <div class="tab-pane" id="social_logins">
         <div class="row">
          <div class="col-md-6">
          <div class="form-group mt-5">
            <div class="custom-control custom-switch">
              <input type="hidden" class="custom-control-input" name="facebook_status" value="0">
              <input type="checkbox" class="custom-control-input" id="facebook_status" name="facebook_status" value="1" {{ (config('app.facebook_status') == 1) ? "checked" : "" }}>
              <label class="custom-control-label" for="facebook_status">{{ __('Enable Facebook login') }}</label>
           </div>
          </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Facebook client ID') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{config("services.facebook.client_id")}}" class="form-control form-control-lg" placeholder="{{ __('your facebook client ID') }}" name="facebook_client_id">
              </div>
           </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Facebook Secret Key') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{config("services.facebook.client_secret")}}" class="form-control form-control-lg" placeholder="{{ __('your facebook secret key') }}" name="facebook_secret_key">
              </div>
           </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Facebook Callback') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{env('FACEBOOK_CALLBACK')}}" class="form-control form-control-lg" readonly>
              </div>
           </div>
          </div>
          <div class="col-md-6">
          <div class="form-group mt-5">
            <div class="custom-control custom-switch">
              <input type="hidden" class="custom-control-input" name="google_status" value="0">
              <input type="checkbox" class="custom-control-input" id="google_status" name="google_status" value="1" {{ (config('app.google_status') == 1) ? "checked" : "" }}>
              <label class="custom-control-label" for="google_status">{{ __('Enable Google login') }}</label>
           </div>
          </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Google client ID') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{config("services.google.client_id")}}" class="form-control form-control-lg" placeholder="{{ __('your google client ID') }}" name="google_client_id">
              </div>
           </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Google Secret Key') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{config("services.google.client_secret")}}" class="form-control form-control-lg" placeholder="{{ __('your google secret key') }}" name="google_secret_key">
              </div>
           </div>
           <div class="form-group mt-5">
              <label class="form-label"><span>{{ __('Google Callback') }}</span></label>
              <div class="form-control-wrap">
               <input type="text" value="{{env('GOOGLE_CALLBACK')}}" class="form-control form-control-lg" readonly>
              </div>
           </div>
          </div>
          </div>
        </div>
        <div class="tab-pane" id="captcha">
         <div class="row">
          <div class="col-md-6">
            
          <div class="form-group mt-5">
            <div class="custom-control custom-switch">
              <input type="hidden" class="custom-control-input" name="captcha_status" value="0">
              <input type="checkbox" class="custom-control-input" id="captcha_status" name="captcha_status" value="1" {{ (config('app.captcha_status') == 1) ? "checked" : "" }}>
              <label class="custom-control-label" for="captcha_status">{{ __('Enable Captcha') }}</label>
           </div>
          </div>
          <div class="form-group mt-5">
             <label class="form-label"><span> {{ __('Captcha type') }}</span></label>
             <div class="form-control-wrap">
                <select class="form-select" data-search="off" data-ui="lg" name="captcha_type">
                   <option value="default" {{ config('app.captcha_type') == 'default' ? 'selected' : '' }}> {{ __('Default') }} </option>
                   <option value="recaptcha" {{ config('app.captcha_type') == 'recaptcha' ? 'selected' : '' }}> {{ __('Google Recaptcha') }} </option>
               </select>
             </div>
          </div>
          </div>
            <div class="col-md-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Recaptcha Site Key') }}</span></label>
                 <div class="form-control-wrap">
                  <input type="text" value="{{config("app.recaptcha_site_key")}}" class="form-control form-control-lg" placeholder="{{ __('your recaptcha site key') }}" name="recaptcha_site_key">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Recaptcha Secret Key') }}</span></label>
                 <div class="form-control-wrap">
                  <input type="text" value="{{config("app.recaptcha_secret_key")}}" class="form-control form-control-lg" placeholder="{{ __('your recaptcha secret key') }}" name="recaptcha_secret_key">
                 </div>
              </div>
            </div>
          </div>
        </div>
		    <div class="tab-pane" id="payment">
				<div class="data-head mt-5 mb-1">
           <h6 class="overline-title">{{ __(' General ') }}</h6>
         </div>
    			<div class="row">
    			 <div class="col">
             <div class="form-group mt-5">
                <label class="form-label"><span> {{ __('Payments System Is Enabled') }}</span></label>
                <div class="form-control-wrap">
                   <select class="form-select" data-search="off" data-ui="lg" name="payment_system">
                      <option value="1" {{settings('payment_system') ? "selected" : ""}}> {{ __('Yes') }}</option>
                      <option value="0" {{!settings('payment_system') ? "selected" : ""}}> {{ __('No') }}</option>
                  </select>
                </div>
                <p>{{ __('Disabling the payment system will remove all the options for the users to upgrade their accounts or see any payment related information.') }}</p>
             </div>
    			 </div>
    			 <div class="col">
             <div class="form-group mt-5">
                <label class="form-label"><span>{{ __('Currency') }}</span></label>
                <div class="form-control-wrap">
                 <input type="text" value="{{settings('currency')}}" class="form-control form-control-lg" placeholder="{{ __('currency') }}" name="currency">
                 <p>{{ __('Enter your currency code. ex: USD') }}</p>
                </div>
             </div>
    			 </div>
    			</div>

            <div class="row">
		          <div class="col-md-6">
              @if (license('license') !== 'Extended License')
              <div class="data-head mt-5 mb-1">
                <h6 class="overline-title">{{ __('Upgrade') }}</h6>
              </div>
              <div class="mt-6">
                <div class="d-flex align-items-center justify-content-center">
                  {{ __('Upgrade to extended license to use other payment gateways like stripe, razorpay, paystack, etc') }}
                </div>
              </div>
              @endif
			        <div class="data-head mt-5 mb-1">
                <h6 class="overline-title">{{ __('Paypal') }}</h6>
              </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="paypal_status">
                       <option value="1" {{(env("PAYPAL_STATUS") == 1) ? "selected" : ""}}> {{ __('Yes') }}</option>
                       <option value="0" {{(env("PAYPAL_STATUS") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Mode') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="paypal_mode">
                       <option value="live" {{(env("PAYPAL_MODE") == 'live') ? "selected" : ""}}> {{ __('Live') }}</option>
                       <option value="sandbox" {{(env("PAYPAL_MODE") == 'sandbox') ? "selected" : ""}}> {{ __('Sandbox') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Client Id') }}</span></label>
                 <div class="form-control-wrap">
					 <input type="text" value="{{env("PAYPAL_CLIENT_ID")}}" class="form-control form-control-lg" placeholder="{{ __('your client id') }}" name="paypal_client_id">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Secret') }}</span></label>
                 <div class="form-control-wrap">
        					 <input type="text" value="{{env("PAYPAL_SECRET")}}" class="form-control form-control-lg" placeholder="{{ __('your secret') }}" name="paypal_secret">
                 </div>
              </div>
              @if (license('license') == 'Extended License')
            <div class="form-group mt-5">
              <div class="data-head mt-5 mb-1">
                <h6 class="overline-title">{{ __('PayTM') }}</h6>
              </div>
                <label>{{ __('Status') }}</label>
              <select name="paytm_status" class="form-select custom-select" data-search="on" data-ui="lg">
                <option value="1" {{ env('PAYTM_STATUS') == 1 ? 'selected' : '' }}>{{ __('Activate') }}</env>
                <option value="0" {{ env('PAYTM_STATUS') == 0 ? 'selected' : '' }}>{{ __('Dsiable') }}</option>
              </select>
              <div class="mt-4"></div>
                <label>{{ __('Environment') }}</label>
              <select name="paytm_environment" class="form-select custom-select mt-4" data-search="on" data-ui="lg">
                <option value="production" {{ env('PAYTM_ENVIRONMENT') == 'production' ? 'selected' : '' }}>{{ __('Production') }}</option>
                <option value="local" {{ env('PAYTM_ENVIRONMENT') == 'local' ? 'selected' : '' }}>{{ __('Local') }}</option>
              </select>

              <div class="form-control-wrap mt-3">
                <label>{{ __('Merchant ID') }}</label>
               <input type="text" value="{{ env('PAYTM_MERCHANT_ID') }}" class="form-control form-control-lg" placeholder="{{ __('Merchant ID') }}" name="paytm_merchant_id">
              </div>
              <div class="form-control-wrap mt-3">
                <label>{{ __('Merchant Key') }}</label>
               <input type="text" value="{{ env('PAYTM_MERCHANT_KEY') }}" class="form-control form-control-lg" placeholder="{{ __('Merchant Key') }}" name="paytm_merchant_key">
              </div>
              <div class="form-control-wrap mt-3">
                <label>{{ __('Merchant Website') }}</label>
               <input type="text" value="{{ env('PAYTM_MERCHANT_WEBSITE') }}" class="form-control form-control-lg" placeholder="{{ __('Merchant Website') }}" name="paytm_merchant_website">
              </div>
              <div class="form-control-wrap mt-3">
                <label>{{ __('Channel') }}</label>
               <input type="text" value="{{ env('PAYTM_CHANNEL') }}" class="form-control form-control-lg" placeholder="{{ __('Channel') }}" name="paytm_channel">
              </div>
              <div class="form-control-wrap mt-3">
                <label>{{ __('Industry Type') }}</label>
               <input type="text" value="{{ env('PAYTM_INDUSTRY_TYPE') }}" class="form-control form-control-lg" placeholder="{{ __('Industry Type') }}" name="paytm_industrytype">
              </div>
           </div>

			       <div class="data-head mt-5 mb-1">
	            <h6 class="overline-title">{{ __('Paystack') }}</h6>
	           </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="paystack_status">
                       <option value="0" {{(env("PAYSTACK_STATUS") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                       <option value="1" {{env("PAYSTACK_STATUS") == 1 ? "selected" : ""}}> {{ __('Yes') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Public Key') }}</span></label>
                 <div class="form-control-wrap">
					 <input type="text" value="{{env("PAYSTACK_PUBLIC_KEY")}}" class="form-control form-control-lg" placeholder="{{ __('your public key') }}" name="paystack_public_key">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Secret key') }}</span></label>
                 <div class="form-control-wrap">
				         <input type="text" value="{{env("PAYSTACK_SECRET_KEY")}}" class="form-control form-control-lg" placeholder="{{ __('your secret key') }}" name="paystack_secret_key">
                 </div>
              </div>
              <div class="data-head mt-5 mb-1">
                <h6 class="overline-title">{{ __('MidTrans') }}</h6>
              </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="midtrans_status">
                       <option value="1" {{(env("MIDTRANS_STATUS") == 1) ? "selected" : ""}}> {{ __('Yes') }}</option>
                       <option value="0" {{(env("MIDTRANS_STATUS") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Mode') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="midtrans_mode">
                       <option value="live" {{(env("MIDTRANS_MODE") == 'live') ? "selected" : ""}}> {{ __('Live') }}</option>
                       <option value="sandbox" {{(env("MIDTRANS_MODE") == 'sandbox') ? "selected" : ""}}> {{ __('Sandbox') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Client Key') }}</span></label>
                 <div class="form-control-wrap">
                    <input type="text" value="{{env("MIDTRANS_CLIENT_KEY")}}" class="form-control form-control-lg" placeholder="{{ __('your client key') }}" name="midtrans_client_key">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Server Key') }}</span></label>
                 <div class="form-control-wrap">
                   <input type="text" value="{{env("MIDTRANS_SERVER_KEY")}}" class="form-control form-control-lg" placeholder="{{ __('your server key') }}" name="midtrans_server_key">
                 </div>
              </div>
              @endif
		     </div>
		     <div class="col-md-6">
		     	
			       <div class="data-head mt-5 mb-1">
	            <h6 class="overline-title">{{ __('Bank Transfer') }}</h6>
	           </div>

              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="bank_status">
                       <option value="0" {{(config('app.bank_status') == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                       <option value="1" {{config('app.bank_status') == 1 ? "selected" : ""}}> {{ __('Yes') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Bank Details including bank name') }}</span></label>
                 <div class="form-control-wrap">
					         <input type="text" value="{{config("app.bank_details")}}" class="form-control form-control-lg" placeholder="{{ __('your key id') }}" name="bank_details">
                 </div>
              </div>
              @if (license('license') == 'Extended License')
             <div class="data-head mt-5 mb-1">
              <h6 class="overline-title">{{ __('Razor Pay') }}</h6>
             </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="rozor_status">
                       <option value="0" {{(env("RAZOR_STATUS") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                       <option value="1" {{env("RAZOR_STATUS") == 1 ? "selected" : ""}}> {{ __('Yes') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Key Id') }}</span></label>
                 <div class="form-control-wrap">
                   <input type="text" value="{{config("app.razor_key")}}" class="form-control form-control-lg" placeholder="{{ __('your key id') }}" name="razor_key_id">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Key Secret') }}</span></label>
                 <div class="form-control-wrap">
                  <input type="text" value="{{config("app.razor_secret")}}" class="form-control form-control-lg" placeholder="{{ __('your secret key') }}" name="rozor_secret_key">
                 </div>
              </div>
             <div class="data-head mt-5 mb-1">
              <h6 class="overline-title">{{ __('Stripe') }}</h6>
             </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="stripe_status">
                       <option value="0" {{(config("app.stripe_status") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                       <option value="1" {{config("app.stripe_status") == 1 ? "selected" : ""}}> {{ __('Yes') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Client Id') }}</span></label>
                 <div class="form-control-wrap">
                   <input type="text" value="{{config("app.stripe_client")}}" class="form-control form-control-lg" placeholder="{{ __('your client id') }}" name="stripe_client">
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Secret Id') }}</span></label>
                 <div class="form-control-wrap">
                  <input type="text" value="{{config("app.stripe_secret")}}" class="form-control form-control-lg" placeholder="{{ __('your secret key') }}" name="stripe_secret">
                 </div>
               </div>

              <div class="data-head mt-5 mb-1">
                <h6 class="overline-title">{{ __('Mercadopago') }}</h6>
              </div>
              <div class="form-group mt-3">
                 <label class="form-label"><span>{{ __('Status') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="mercadopago_status">
                       <option value="1" {{(env("MERCADOPAGO_STATUS") == 1) ? "selected" : ""}}> {{ __('Yes') }}</option>
                       <option value="0" {{(env("MERCADOPAGO_STATUS") == 0) ? "selected" : ""}}> {{ __('No') }}</option>
                   </select>
                 </div>
              </div>
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Access token') }}</span></label>
                 <div class="form-control-wrap">
                    <input type="text" value="{{env("MERCADOPAGO_ACCESS_TOKEN")}}" class="form-control form-control-lg" placeholder="{{ __('your access token') }}" name="mercadopago_access_token">
                 </div>
              </div>
              @endif
		          </div>
            </div>
		    </div>
		    <div class="tab-pane" id="ads">
		    	<div class="form-group mt-5">
		    		<div class="custom-control custom-switch">
					    <input type="hidden" class="custom-control-input" name="ads_enabled" value="0">
					    <input type="checkbox" class="custom-control-input" id="ads_switch" name="ads_enabled" value="1" {{ settings('ads.enabled') ? "checked" : "" }}>
					    <label class="custom-control-label" for="ads_switch">{{ __('Enable ads') }}</label>
					</div>
		    	</div>
		    	<h5>{{ __('These fields accept text or html.') }}</h5>
		    	<p>{{ __('Note ads can remove depending on user plan') }}</p>
				 <div class="data-head mt-5 mb-5">
           <h6 class="overline-title">{{ __('Site | Dashboard ads') }}</h6>
         </div>
		    	<div class="row mt-4">
		    		<div class="col-md-6 mt-4">
				    	<div class="form-group">
						    <label class="form-label"><span>{{ __('Header') }}</span></label>
						    <div class="form-control-wrap">
						        <textarea class="form-control form-control-lg" placeholder="{{ __('input header code') }}" name="ads_site_header">{{settings('ads.site_header')}}</textarea>
						    </div>
						</div>
		    		</div>
		    		<div class="col-md-6 mt-4">
				    	<div class="form-group">
						    <label class="form-label"><span>{{ __('Footer') }}</span></label>
						    <div class="form-control-wrap">
						        <textarea class="form-control form-control-lg" placeholder="{{ __('input header footer') }}" name="ads_site_footer">{{settings('ads.site_footer')}}</textarea>
						    </div>
						</div>
		    		</div>
		    	</div>

				 <div class="data-head mt-5 mb-5">
           <h6 class="overline-title">{{ __('Store ads') }}</h6>
         </div>
		    	<div class="row">
		    		<div class="col-md-6 mt-4">
				    	<div class="form-group">
						    <label class="form-label"><span>{{ __('Header') }}</span></label>
						    <div class="form-control-wrap">
						        <textarea class="form-control form-control-lg" placeholder="{{ __('input header code') }}" name="ads_store_header">{{settings('ads.store_header')}}</textarea>
						    </div>
						</div>
		    		</div>
		    		<div class="col-md-6 mt-4">
				    	<div class="form-group">
						    <label class="form-label"><span>{{ __('Footer') }}</span></label>
						    <div class="form-control-wrap">
						        <textarea class="form-control form-control-lg" placeholder="{{ __('input header footer') }}" name="ads_store_footer">{{settings('ads.store_footer')}}</textarea>
						    </div>
						</div>
		    		</div>
		    	</div>
		    </div>



		    <!-- Custom JS / CSS -->

		    <div class="tab-pane" id="custom-js-css">
		    	<div class="form-group mt-5">
		    		<div class="custom-control custom-switch">
					    <input type="hidden" class="custom-control-input" name="custom_code_enabled" value="0">
					    <input type="checkbox" class="custom-control-input" id="custom_js_css" name="custom_code_enabled" value="1" {{ settings('custom_code.enabled') ? "checked" : "" }}>
					    <label class="custom-control-label" for="custom_js_css">{{ __('Enable Custom Code') }}</label>
					</div>
		    	</div>
		    	<div class="row">
		    		<div class="col-md-12">
				    	<div class="form-group mt-5 mt-lg-2">
						    <label class="form-label"><em class="icon ni ni-js"></em> <span>{{ __('Code') }}</span></label>
						    <div class="form-control-wrap">
						      <textarea class="form-control form-control-lg code" placeholder="{{ __('input code') }}" name="custom_code_head">{{settings('custom_code.head')}}</textarea>
						    </div>
						  </div>
		    		</div>
		    	</div>
		    </div>




		    <!-- User -->
		    <div class="tab-pane" id="user">
				<div class="data-head mt-5 mb-2">
          <h6 class="overline-title">{{ __('Registration') }}</h6>
        </div>
		    	<div class="row">
            <div class="col-6">
              <div class="form-group mt-5">
                <div class="custom-control custom-switch">
                  <input type="hidden" name="registration" value="0">
                  <input type="checkbox" value="1" class="custom-control-input" id="registration" name="registration" {{ settings('registration') ? "checked" : "" }}>
                  <label class="custom-control-label" for="registration">{{ __('Enable Registration') }}</label>
              </div>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Enable email verification') }}</span></label>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="email_activation">
                      <option value="1" {{ settings('email_activation') ? "selected" : "" }}>On</option>
                      <option value="0" {{ !settings('email_activation') ? "selected" : "" }}>Off</option>
                  </select>
                </div>
             </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Demo User') }}</span></label>
                 <p>{{ __('This will show users on index page') }}</p>
                 <div class="form-control-wrap">
                    <select class="form-select" data-search="off" data-ui="lg" name="user_demo_user">
                      @foreach (App\User::get() as $user)
                        <option value="{{ $user->id }}" {{ (settings('user.demo_user') == $user->id) ? "selected" : "" }}>{{ $user->username }}</option>
                      @endforeach
                  </select>
                </div>
             </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Domains') }}</span></label>
                  <p>{{ __('if checked user profile will be shown on all multidomain. if unchecked user profile will be limited to selected domain') }}</p>
                <div class="custom-control custom-switch">
                  <input type="hidden" name="user_domains_restrict" value="0">
                  <input type="checkbox" value="1" class="custom-control-input" id="user_domains_restrict" name="user_domains_restrict" {{ settings('user.domains_restrict') ? "checked" : "" }}>
                  <label class="custom-control-label" for="user_domains_restrict"></label>
                </div>
              </div>
            </div>
            <div class="col-12">
             <div class="data-head mt-5 mb-5">
               <h6 class="overline-title">{{ __('Products') }}</h6>
             </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Products image limits') }}</span></label>
                  <p>{{ __('How many products image can be posted') }}</p>
                 <div class="form-control-wrap">
                  <select class="form-select" data-search="off" data-ui="lg" name="user_products_image_limit">
                    @for ($i = 1; $i < 10; $i++)
                    <option value="{{ $i }}" {{ (settings('user.products_image_limit') == $i) ? "selected" : "" }}>{{ $i }} {{ __('Products') }}</option>
                    @endfor
                  </select>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Products image size') }}</span></label>
                  <p>{{ __('Max Products size') }}</p>
                 <div class="form-control-wrap">
                  <select class="form-select" data-search="off" data-ui="lg" name="user_products_image_size">
                    @for ($i = 1; $i < 20; $i++)
                    <option value="{{ $i }}" {{ (settings('user.products_image_size') == $i) ? "selected" : "" }}>{{ $i }} {{ __('Mb') }}</option>
                    @endfor
                  </select>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="form-group mt-5">
                 <label class="form-label"><span>{{ __('Wildcard subdomain creation') }}</span></label>
                  <p>Please be sure to create a wildcard subdomain with *.{{parse_url(env('APP_URL'))['host'] ?? ''}} pointing to the ecom folder on your web server. This option creates a subdomain on user registration and set it as active</p>
                 <div class="form-control-wrap">
                  <select class="form-select" data-search="off" data-ui="lg" name="userwildcard">
                    @foreach ([0 => 'Disable', 1 => 'Enable'] as $key => $value)
                      <option value="{{ $key }}" {{ env('APP_USER_WILDCARD') == $key ? 'selected' : '' }}>{{ $value }}</option>
                    @endforeach
                  </select>
                </div>
                <label for="" class="form-label mt-5">Wildcard domain</label>
                <p>
                  The domain you want to use for wildcard. If empty it'll use the app domain <b>"{{parse_url(env('APP_URL'))['host'] ?? ''}}"</b>. Store will come out as <b>"example.{{parse_url(env('APP_URL'))['host'] ?? ''}}"</b>
                </p>
                <p>Input domain without any protocol like http:// or https://</p>

                <input type="text" class="form-control" name="envUpdate[APP_USER_WILDCARD_DOMAIN]" value="{{ env('APP_USER_WILDCARD_DOMAIN') }}">
              </div>
            </div>
				</div>
		    </div>
		    <div class="tab-pane" id="social">
		    	<div class="row mt-5">
		    		<div class="col-6 col-lg-4">
				    	<div class="form-group mt-2">
						    <label class="form-label"><em class="icon ni ni-facebook-f"></em> <span>{{ __('Facebook') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" value="{{ settings('social.facebook') }}" class="form-control form-control-lg" placeholder="{{ __('your username') }}" name="social_facebook">
						    </div>
						</div>
				    </div>
		    		<div class="col-6 col-lg-4">
				    	<div class="form-group mt-2">
						    <label class="form-label"><em class="icon ni ni-instagram"></em> <span>{{ __('Instagram') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" value="{{ settings('social.instagram') }}" class="form-control form-control-lg" placeholder="{{ __('your username') }}" name="social_instagram">
						    </div>
						</div>
				    </div>
		    		<div class="col-6 col-lg-4">
				    	<div class="form-group mt-5 mt-lg-2">
						    <label class="form-label"><em class="icon ni ni-youtube"></em> <span>{{ __('Youtube') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" value="{{ settings('social.youtube') }}" class="form-control form-control-lg" placeholder="{{ __('channel id') }}" name="social_youtube">
						    </div>
						</div>
				    </div>
		    		<div class="col-6 col-lg-4">
				    	<div class="form-group mt-5">
						    <label class="form-label"><em class="icon ni ni-twitter"></em> <span>{{ __('Twitter') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" value="{{ settings('social.twitter') }}" class="form-control form-control-lg" placeholder="{{ __('your username') }}" name="social_twitter">
						    </div>
						</div>
				    </div>
		    		<div class="col-6 col-lg-4">
				    	<div class="form-group mt-5">
						    <label class="form-label"><em class="icon ni ni-whatsapp"></em> <span>{{ __('Whatsapp') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" value="{{ settings('social.whatsapp') }}" class="form-control form-control-lg" placeholder="{{ __('phone number including county code') }}" name="social_whatsapp">
						    </div>
						</div>
				    </div>
				</div>
		    </div>
		    <div class="tab-pane" id="emailsnotify">
		    	<div class="row">
		    		
		    	<div class="col-md-6">
				 	<div class="form-group mt-5 mt-lg-2">
					    <label class="form-label"><em class="icon ni ni-bell-fill"></em> <span> {{ __('Emails to be notify') }}</span></label>
					    <div class="form-control-wrap">
					        <textarea class="form-control form-control-lg" placeholder="{{ __('input emails') }}" name="email_notify_emails">{{ settings('email_notify.emails') }}</textarea>
					    </div>
		    			<p>{{ __('Emails that will receive a notification when one of the bottom actions are performed. Add valid email addresses separated by a comma.') }}</p>
					</div>
		    	</div>
		    	<div class="col-md-6">
		    		
		    	<div class="row mt-4">
						<div class="row">
				    	<div class="col-12 mt-4 mb-4">
					        <div class="custom-control custom-checkbox">
							    <input type="hidden" name="email_notify_user" value="0">
							    <input type="checkbox" class="custom-control-input" name="email_notify_user" id="email_notify_user"{{ settings('email_notify.user') == 1 ? "checked" : "" }} value="1">
							    <label class="custom-control-label" for="email_notify_user">{{ __('New User') }}</label>
							</div>
							<p>{{ __('Receive an email when a new users registers to the website.') }}</p>
				    	</div>				
					    	<div class="col-6 mt-4">
						       <div class="custom-control custom-checkbox">
								    <input type="hidden" name="email_notify_payment" value="0">
							      <input type="checkbox" class="custom-control-input" name="email_notify_payment" id="email_notify_payment"{{ settings('email_notify.payment') ? "checked" : "" }} value="1">
							      <label class="custom-control-label" for="email_notify_payment">{{ __('New Payment') }}</label>
							  </div>
							  <p>{{ __('Receive an email when a new payment is successfully processed.') }}</p>
							</div>
					    	<div class="col-6 mt-4">
						       <div class="custom-control custom-checkbox">
								    <input type="hidden" name="email_notify_bank_transfer" value="0">
							      <input type="checkbox" class="custom-control-input" name="email_notify_bank_transfer" id="email_notify_bank_transfer"{{ settings('email_notify.bank_transfer') ? "checked" : "" }} value="1">
							      <label class="custom-control-label" for="email_notify_bank_transfer">{{ __('New Bank Transfer') }}</label>
							  </div>
							  <p>{{ __('Receive an email when a new bank transfer request is made.') }}</p>
							</div>
						</div>
		    	  </div>
		    	</div>
		      </div>
		    </div>

		    <!-- Site -->
		    <div class="tab-pane" id="site">
			   <div class="data-head mt-5 mb-2">
	              <h6 class="overline-title">{{ __('Images') }}</h6>
	           </div>
	           <div class="row">
	           	<div class="col">
			   		<div class="image-upload pages {{(!empty(settings('logo')) ? file_exists(public_path('img/logo/' . settings('logo'))) ? "active" : "" : "")}}">
			                 <label for="upload">{{ __('Click here or drop an image for logo') }}</label>
			                 <input type="file" id="upload" name="logo" class="upload">
			                 <img src="{{ logo() }}" alt=" ">
			            </div>
	           	</div>
	           	<div class="col">
			   		<div class="image-upload pages {{ file_exists(public_path('img/favicon/' . settings('favicon'))) ? "active" : ""}}">
			                 <label for="upload">{{ __('Click here or drop an image for favicon') }}</label>
			                 <input type="file" id="upload" name="favicon" class="upload">
			                 <img src="{{ favicon() }}" alt=" ">
			            </div>
	           	</div>
	           </div>
            <div class="col-6 col-lg-4">
              <div class="form-group mt-5">
                <label class="form-label"><span>{{ __('Show contact form') }}</span></label>
                <div class="form-control-wrap">
                 <select class="form-select" data-search="off" data-ui="lg" name="contact">
                    <option value="0" {{ !settings('contact') ? "selected" : "" }}> {{ __('Off') }}</option>
                    <option value="1" {{ settings('contact') ? "selected" : "" }}> {{ __('On') }}</option>
                </select>
                </div>
              </div>
              <div class="form-group mt-5">
                <label class="form-label"><span>{{ __('Show store count on homepage') }}</span></label>
                <div class="form-control-wrap">
                 <select class="form-select" data-search="off" data-ui="lg" name="site_store_count">
                    <option value="0" {{ !settings('site.store_count') ? "selected" : "" }}> {{ __('Off') }}</option>
                    <option value="1" {{ settings('site.store_count') ? "selected" : "" }}> {{ __('On') }}</option>
                </select>
                </div>
              </div>
              <div class="form-group mt-5">
                <label class="form-label"><span>{{ __('Show pages on home') }}</span></label>
                <div class="form-control-wrap">
                 <select class="form-select" data-search="off" data-ui="lg" name="site_show_pages">
                    <option value="0" {{ !settings('site.show_pages') ? "selected" : "" }}> {{ __('Off') }}</option>
                    <option value="1" {{ settings('site.show_pages') ? "selected" : "" }}> {{ __('On') }}</option>
                </select>
                </div>
              </div>
            </div>
		    </div>
		    <div class="tab-pane" id="smtp">
		    	<div class="row">
		    		<div class="col-md-6">
				    	<div class="form-group mt-4">
						    <label class="form-label"><span>{{ __('Host') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('SMTP HOST') }}" value="{{ env('MAIL_HOST') }}" name="smtp_host">
						    </div>
						</div>
		    		</div>
		    		<div class="col-md-6">
                       <div class="form-group mt-4">
                          <label class="form-label"><span>{{ __('From Email') }}</span></label>
                          <div class="form-control-wrap">
						    <input type="text" class="form-control form-control-lg" placeholder="{{ __('SMTP FROM ADDRESS') }}" value="{{ env('MAIL_FROM_ADDRESS') }}" name="smtp_from_address">
                          </div>
                          <p>{{ __("The email that the users get the email from / the 'reply-to'") }}</p>
                       </div>
		    		</div>
		    	</div>
                <div class="form-group mt-4">
                   <label class="form-label"><span>{{ __('From Name') }}</span></label>
                   <div class="form-control-wrap">
				     <input type="text" class="form-control form-control-lg" placeholder="SMTP FROM NAME" value="{{ env('MAIL_FROM_NAME') }}" name="smtp_from_name">
                   </div>
                    <p>{{ __('Empty to use default app name') }}</p>
                </div>
		    	<div class="row">
		    		<div class="col-4">
				    	<div class="form-group mt-4">
						    <label class="form-label"><span>{{ __('Port') }}</span></label>
						    <div class="form-control-wrap">
                               <select class="form-select" data-search="off" data-ui="lg" name="smtp_encryption">
                                  <option value="ssl" {{(env('MAIL_ENCRYPTION') == 'ssl') ? 'selected' : ''}}> {{ __('SSL') }}</option>
                                  <option value="tls" {{(env('MAIL_ENCRYPTION') == 'tls') ? 'selected' : ''}}> {{ __('TLS') }}</option>
                              </select>
						    </div>
						</div>
		    		</div>
		    		<div class="col-8">
                       <div class="form-group mt-4">
                          <label class="form-label"><span>{{ __('Port') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('SMTP PORT') }}" value="{{ env('MAIL_PORT') }}" name="smtp_port">
						    </div>
                       </div>
		    		</div>
		    	</div>
		    	<div class="row">
		    		<div class="col-6">
				    	<div class="form-group mt-4">
						    <label class="form-label"><span>{{ __('Username') }}</span></label>
						    <div class="form-control-wrap">
						        <input type="text" class="form-control form-control-lg" placeholder="{{ __('SMTP USERNAME') }}" value="{{ env('MAIL_USERNAME') }}" name="smtp_username">
						    </div>
						</div>
		    		</div>
		    		<div class="col-6">
                       <div class="form-group mt-4">
                          <label class="form-label"><span>{{ __('Password') }}</span></label>
                          <div class="form-control-wrap">
						    <input type="text" class="form-control form-control-lg" placeholder="{{ __('SMTP PASSWORD') }}" value="{{ env('MAIL_PASSWORD') }}" name="smtp_password">
                          </div>
                       </div>
		    		</div>
		    	</div>
		    </div>
		<div class="form-group mt-5">
			<button type="submit" class="btn btn-primary w-50"><em class="icon ni ni-save-fill"></em> <span>{{ __('Save') }}</span></button>
		</div>
	</div>
</form>
@endsection
